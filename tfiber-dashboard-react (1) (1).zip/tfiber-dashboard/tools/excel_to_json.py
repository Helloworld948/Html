"""
Convert the workbook sheet "Total Connections Detailed Data" into data/connections.json.

Usage (optional helper - the dashboard itself needs no Python):
  pip install pandas openpyxl
  python tools/excel_to_json.py "T_Fiber_....xlsx"                       # full data, array of objects
  python tools/excel_to_json.py "T_Fiber_....xlsx" --sample 1500         # small stratified sample
  python tools/excel_to_json.py "T_Fiber_....xlsx" --columnar            # smaller file for very large data

Only the columns the dashboard uses are exported. Original header names are kept
(the dashboard's mapper in js/mapper.js knows them); contact details are NOT exported.
"""
import argparse, json
import pandas as pd

SHEET = "Total Connections Detailed Data"
COLUMNS = [
    "GI Name", "Department", "Connection Catogory", "PO Status", "LCO/MSI/TSP",
    "LCO Operator Name", "Litup", "Package", "District", "Mandal Name",
    "Solution Type", "Delivery Mode (Switch/ Router/ ONT/Wireless)",
    "Service Provisioned (Yes/NO)", "SAC Form Status", "Disconnection Status",
]

def clean(c):
    return " ".join(str(c).replace("\n", " ").split())

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("xlsx")
    ap.add_argument("--out", default="data/connections.json")
    ap.add_argument("--sheet", default=SHEET)
    ap.add_argument("--header-row", type=int, default=1, help="0-based header row (default 1)")
    ap.add_argument("--sample", type=int, default=0, help="stratified sample size (0 = all rows)")
    ap.add_argument("--columnar", action="store_true", help='write {"columns":[...],"rows":[[...]]}')
    a = ap.parse_args()

    df = pd.read_excel(a.xlsx, sheet_name=a.sheet, header=a.header_row, engine="openpyxl")
    df.columns = [clean(c) for c in df.columns]
    df = df[[c for c in COLUMNS if c in df.columns]].copy()
    df = df.dropna(how="all")
    for c in df.columns:
        df[c] = df[c].map(lambda v: " ".join(str(v).split()) if pd.notna(v) else None)

    if a.sample and a.sample < len(df):
        keep = df[(df["PO Status"].str.upper() == "NETWORK") |
                  (df["Connection Catogory"] == "Private Enterprise") |
                  (df["Disconnection Status"].str.lower() == "yes")]
        rest = df.drop(keep.index)
        strata = rest[["Connection Catogory", "PO Status", "Litup"]].fillna("-").astype(str).agg("|".join, axis=1)
        frac = (a.sample - len(keep)) / len(rest)
        picked = rest.groupby(strata, group_keys=False).apply(
            lambda g: g.sample(max(1, round(len(g) * frac)), random_state=7))
        df = pd.concat([keep, picked]).sort_index()

    df = df.astype(object).where(df.notna(), None)
    if a.columnar:
        payload = {"columns": list(df.columns), "rows": df.values.tolist()}
    else:
        payload = df.to_dict(orient="records")
    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, separators=(",", ":"))
    print(f"wrote {len(df):,} records -> {a.out}")

if __name__ == "__main__":
    main()
