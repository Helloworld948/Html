import { useCallback, useMemo, useState } from 'react';
import { config, FILTERS } from './config';
import { useDashboardData } from './hooks';
import { aggregate, applyFilters, computeKpis, facets } from './lib/calc';
import { fmt } from './lib/theme';
import MultiSelect from './components/MultiSelect';
import KpiCard from './components/KpiCard';
import ChartCard from './components/ChartCard';
import { ColumnChart, DonutChart, HBarChart } from './components/charts';

const EMPTY = Object.fromEntries(FILTERS.map((f) => [f.key, []]));
const sacSet = new Set(config.sacReceived);

export default function App() {
  const data = useDashboardData();
  if (data.status === 'loading') return <div className="state">Loading dashboard…</div>;
  if (data.status === 'error') {
    return <div className="state error"><h2>Could not load data</h2><p>{data.message}</p><p>Serve the folder over HTTP (<code>npm run dev</code> or <code>npm run preview</code>) rather than opening index.html directly.</p></div>;
  }
  return <Dashboard {...data} />;
}

function Dashboard({ rows, excluded, totalSource, reference, missingColumns }) {
  const [filters, setFilters] = useState(EMPTY);
  const [basis, setBasis] = useState('po');
  const [allDistricts, setAllDistricts] = useState(false);
  const [opQuery, setOpQuery] = useState('');
  const [showRecon, setShowRecon] = useState(false);

  const options = useMemo(() => facets(rows), [rows]);
  const filtered = useMemo(() => applyFilters(rows, filters), [rows, filters]);
  const kpi = useMemo(() => computeKpis(filtered, basis, sacSet), [filtered, basis]);
  const agg = useMemo(() => aggregate(filtered), [filtered]);

  const activeChips = FILTERS.flatMap((f) => filters[f.key].map((v) => ({ key: f.key, label: f.label, value: v })));
  const hasFilters = activeChips.length > 0;
  const setFilter = useCallback((key, vals) => setFilters((p) => ({ ...p, [key]: vals })), []);
  const toggleValue = useCallback((key, value) => setFilters((p) => ({
    ...p, [key]: p[key].includes(value) ? p[key].filter((x) => x !== value) : [...p[key], value],
  })), []);

  const pickDistrict = useCallback((v) => toggleValue('district', v), [toggleValue]);
  const pickPackage = useCallback((v) => toggleValue('pkg', v), [toggleValue]);
  const pickCategory = useCallback((v) => toggleValue('cat', v), [toggleValue]);
  const pickPo = useCallback((v) => toggleValue('po', v), [toggleValue]);
  const pickOperator = useCallback((v) => { if (v !== 'Others') toggleValue('op', v); }, [toggleValue]);

  // Operator chart: Top N + Others
  const operatorData = useMemo(() => {
    const top = agg.operators.slice(0, config.operatorTopN).map((o) => ({ name: o.name, y: o.total }));
    const rest = agg.operators.slice(config.operatorTopN).reduce((s, o) => s + o.total, 0);
    return rest ? [...top, { name: 'Others', y: rest }] : top;
  }, [agg.operators]);
  const districtData = allDistricts ? agg.district : agg.district.slice(0, config.districtTopN);
  const opRows = useMemo(() => {
    const t = opQuery.trim().toLowerCase();
    return t ? agg.operators.filter((o) => o.name.toLowerCase().includes(t)) : agg.operators;
  }, [agg.operators, opQuery]);

  const compare = !hasFilters;                      // reference figures only apply to the unfiltered view
  const compareAll = compare && basis === 'po';      // lit-up..disconnected rules match the summary on PO basis
  const ref = reference || {};
  const baseLabel = basis === 'po' ? 'PO records' : 'PO + POC records';
  const k = (label, value, rule, tone, refVal, refOk = compareAll) => ({ label, value, rule, tone, reference: refVal, showReference: refOk });
  const cards = [
    k('Total User Connectivity', kpi.total, 'Household, Private Enterprise, GI-Enterprise with PO or POC', 'primary', ref.total, compare),
    k('PO Count', kpi.po, 'PO Status = PO', 'primary', ref.po, compare),
    k('POC Count', kpi.poc, 'PO Status = POC', 'primary', ref.poc, compare),
    k('Lit-Up Count', kpi.lit, `${baseLabel} with Litup = Yes`, 'good', ref.litUp),
    k('Yet to Lit-Up', kpi.yet, `${baseLabel} with Litup = No or blank`, 'warn', ref.yetToLitUp),
    k('Service Provisioned', kpi.sp, 'Lit-Up and Service Provisioned = Yes / Disconnected', 'good', ref.serviceProvisioned),
    k('Service Yet to Provision', kpi.spYet, 'Lit-Up minus Service Provisioned', 'warn', ref.serviceYetToProvision),
    k('SAC Form Received', kpi.sac, `SAC status: ${config.sacReceived.join(', ')}`, 'good', ref.sacReceived),
    k('SAC Form Yet to Receive', kpi.sacYet, 'Service Provisioned minus SAC Received', 'warn', ref.sacYetToReceive),
    k('Disconnected', kpi.dis, `${baseLabel} with Disconnection Status = Yes`, 'bad', ref.disconnected),
  ];

  const recon = useMemo(() => {
    if (!reference) return [];
    const base = computeKpis(rows, 'po', sacSet);
    return [
      ['Total user connectivity', base.total, reference.total, 'PO + POC in the 3 categories'],
      ['PO', base.po, reference.po, 'PO Status = PO'],
      ['POC', base.poc, reference.poc, 'PO Status = POC'],
      ['Lit-Up', base.lit, reference.litUp, 'PO and Litup = Yes'],
      ['Yet to Lit-Up', base.yet, reference.yetToLitUp, 'PO and Litup = No / blank'],
      ['Service Provisioned', base.sp, reference.serviceProvisioned, 'PO, Lit-Up, Provisioned = Yes / Disconnected'],
      ['Service Yet to Provision', base.spYet, reference.serviceYetToProvision, 'Lit-Up − Service Provisioned'],
      ['SAC Form Received', base.sac, reference.sacReceived, 'Status mapping pending business confirmation'],
      ['SAC Form Yet to Receive', base.sacYet, reference.sacYetToReceive, 'Service Provisioned − SAC Received'],
      ['Disconnected', base.dis, reference.disconnected, 'PO and Disconnection Status = Yes'],
    ];
  }, [rows, reference]);

  const excludedText = Object.entries(excluded.reasons).map(([r, n]) => `${fmt(n)} with ${r}`).join('; ');

  return (
    <div className="app">
      <header className="topbar">
        <div className="topbar-in">
          <div>
            <h1>T-Fiber End-User Connectivity</h1>
            <p>Status as on {config.asOfLabel} · Source: Total Connections Detailed Data</p>
          </div>
          <div className="topbar-meta">
            <span className="pill">{fmt(filtered.length)} of {fmt(rows.length)} records</span>
          </div>
        </div>
      </header>

      <main className="wrap">
        <section className="filters" aria-label="Filters">
          <div className="filters-grid">
            {FILTERS.map((f) => (
              <MultiSelect key={f.key} label={f.label} options={options[f.key]} selected={filters[f.key]} onChange={(v) => setFilter(f.key, v)} />
            ))}
          </div>
          <div className="filters-foot">
            <div className="chips">
              {activeChips.length === 0 && <span className="muted">No filters applied. Click a chart bar or slice to filter by it.</span>}
              {activeChips.map((c) => (
                <button key={`${c.key}:${c.value}`} className="chip" onClick={() => toggleValue(c.key, c.value)} title="Remove filter">
                  <b>{c.label}:</b> {c.value} <span aria-hidden="true">×</span>
                </button>
              ))}
            </div>
            <button className="btn" disabled={!hasFilters} onClick={() => setFilters(EMPTY)}>Reset filters</button>
          </div>
        </section>

        <div className="scope">
          <span>
            <b>Scope:</b> {fmt(rows.length)} of {fmt(totalSource)} source records are PO or POC in the three connection categories
            {excluded.count ? ` (excluded: ${excludedText})` : ''}. This is why the total is {fmt(rows.length)}, not {fmt(totalSource)}.
          </span>
          <div className="seg" role="group" aria-label="Basis for Lit-Up to Disconnected figures">
            <button className={basis === 'po' ? 'on' : ''} onClick={() => setBasis('po')}>PO only (matches summary)</button>
            <button className={basis === 'all' ? 'on' : ''} onClick={() => setBasis('all')}>PO + POC</button>
          </div>
        </div>

        {missingColumns.length > 0 && <div className="notice">Columns not found in the data file: {missingColumns.join(', ')}</div>}

        {filtered.length === 0 ? (
          <div className="card empty"><h2>No Data Available</h2><p>No records match the selected filters.</p><button className="btn primary" onClick={() => setFilters(EMPTY)}>Reset filters</button></div>
        ) : (
          <>
            <section className="kpis" aria-label="Key figures">
              {cards.map((c) => <KpiCard key={c.label} {...c} />)}
            </section>

            <div className="grid">
              <ChartCard className="span-7" title="District-wise connections" subtitle={allDistricts ? `All ${agg.district.length} districts` : `Top ${Math.min(config.districtTopN, agg.district.length)} of ${agg.district.length} districts`}
                actions={agg.district.length > config.districtTopN && <button className="btn sm" onClick={() => setAllDistricts((v) => !v)}>{allDistricts ? 'Show top 15' : `Show all ${agg.district.length}`}</button>}>
                <HBarChart data={districtData} onPick={pickDistrict} />
              </ChartCard>

              <ChartCard className="span-5" title="LCO operator-wise connections" subtitle={`Top ${config.operatorTopN} operators, rest grouped as Others`}>
                <HBarChart data={operatorData} onPick={pickOperator} color="#0d9488" rowHeight={30} />
                <p className="foot-note">Not charted: {Object.entries(agg.operatorExcluded).map(([n, c]) => `${n} ${fmt(c)}`).join(' · ')}</p>
              </ChartCard>

              <ChartCard className="span-4" title="Package-wise connections" subtitle="Share of connections by package">
                <DonutChart data={agg.pkg} centreLabel="connections" onPick={pickPackage} />
              </ChartCard>
              <ChartCard className="span-4" title="Connection category" subtitle="GI-Enterprise, Household, Private Enterprise">
                <ColumnChart data={agg.cat} onPick={pickCategory} />
              </ChartCard>
              <ChartCard className="span-4" title="PO vs POC" subtitle="Composition of total user connectivity">
                <DonutChart data={agg.po} centreLabel="PO + POC" onPick={pickPo} />
              </ChartCard>

              <ChartCard className="span-12" title="Operator details" subtitle={`${fmt(opRows.length)} operators`}
                actions={<input className="search" placeholder="Search operator…" value={opQuery} onChange={(e) => setOpQuery(e.target.value)} />}>
                <div className="table-wrap">
                  <table>
                    <thead><tr><th>Operator</th><th>Total</th><th>PO</th><th>POC</th><th>Lit-Up</th><th>Provisioned</th></tr></thead>
                    <tbody>
                      {opRows.map((o) => (
                        <tr key={o.name}><td>{o.name}</td><td>{fmt(o.total)}</td><td>{fmt(o.po)}</td><td>{fmt(o.poc)}</td><td>{fmt(o.lit)}</td><td>{fmt(o.sp)}</td></tr>
                      ))}
                      {opRows.length === 0 && <tr><td colSpan="6" className="muted">No operators match.</td></tr>}
                    </tbody>
                  </table>
                </div>
              </ChartCard>
            </div>
          </>
        )}

        {reference && (
          <section className="card recon">
            <header className="card-head">
              <div><h2>Reconciliation with Summary 16-Sep-2026</h2><p>Unfiltered figures computed from the data file versus the workbook summary</p></div>
              <button className="btn sm" onClick={() => setShowRecon((v) => !v)}>{showRecon ? 'Hide' : 'Show'}</button>
            </header>
            {showRecon && (
              <div className="table-wrap">
                <table>
                  <thead><tr><th>Metric</th><th>Rule</th><th>Dashboard</th><th>Summary</th><th>Difference</th></tr></thead>
                  <tbody>
                    {recon.map(([m, a, b, rule]) => (
                      <tr key={m}><td>{m}</td><td className="muted">{rule}</td><td>{fmt(a)}</td><td>{fmt(b)}</td>
                        <td>{a === b ? <span className="badge ok">✓ Match</span> : <span className="badge warn">{a - b > 0 ? '+' : ''}{fmt(a - b)}</span>}</td></tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        )}
      </main>
    </div>
  );
}
