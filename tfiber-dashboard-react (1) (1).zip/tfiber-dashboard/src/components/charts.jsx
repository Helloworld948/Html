import { useMemo } from 'react';
import HighchartsReact from 'highcharts-react-official';
import Highcharts, { COLORS, PALETTE, fmt } from '../lib/theme';

const Chart = ({ options }) => <HighchartsReact highcharts={Highcharts} options={options} containerProps={{ style: { width: '100%' } }} />;

const clickToFilter = (onPick) => ({
  point: { events: { click() { onPick?.(this.name); } } },
  cursor: onPick ? 'pointer' : 'default',
});

/** Horizontal bar: category -> count. Used for districts and operators. */
export function HBarChart({ data, onPick, color = COLORS.primary, seriesName = 'Connections', rowHeight = 26 }) {
  const options = useMemo(() => ({
    chart: { type: 'bar', height: Math.max(180, data.length * rowHeight + 50) },
    xAxis: { type: 'category', labels: { style: { color: COLORS.text, fontSize: '12px' } }, lineWidth: 0, tickLength: 0 },
    yAxis: { min: 0, allowDecimals: false, gridLineDashStyle: 'Dash' },
    legend: { enabled: false },
    tooltip: { pointFormatter() { return `<b>${fmt(this.y)}</b> connections`; }, headerFormat: '<span style="opacity:.75">{point.key}</span><br/>' },
    plotOptions: {
      bar: { borderRadius: 3, pointPadding: 0.12, groupPadding: 0.05, dataLabels: { enabled: true, formatter() { return fmt(this.y); }, style: { fontSize: '11px', fontWeight: '600', color: COLORS.muted, textOutline: 'none' } } },
      series: clickToFilter(onPick),
    },
    series: [{ name: seriesName, color, data: data.map((d) => ({ ...d, color: d.name === 'Others' ? COLORS.slate : color })) }],
  }), [data, onPick, color, seriesName, rowHeight]);
  return <Chart options={options} />;
}

/** Donut with the total in the centre and a legend that shows counts and share. */
export function DonutChart({ data, centreLabel, onPick }) {
  const total = data.reduce((s, d) => s + d.y, 0);
  const options = useMemo(() => ({
    chart: { type: 'pie', height: 300 },
    title: { text: `<span style="font-size:24px;font-weight:700;color:${COLORS.text}">${fmt(total)}</span><br/><span style="font-size:12px;color:${COLORS.muted}">${centreLabel}</span>`, useHTML: true, verticalAlign: 'middle', y: -18, align: 'center' },
    tooltip: { pointFormatter() { return `<b>${fmt(this.y)}</b> (${this.percentage.toFixed(1)}%)`; }, headerFormat: '<span style="opacity:.75">{point.key}</span><br/>' },
    legend: {
      enabled: true, align: 'center', verticalAlign: 'bottom', layout: 'horizontal', itemMarginBottom: 2,
      labelFormatter() { return `${this.name} · ${fmt(this.y)} (${this.percentage.toFixed(1)}%)`; },
    },
    plotOptions: {
      pie: { innerSize: '68%', size: '88%', center: ['50%', '42%'], showInLegend: true, dataLabels: { enabled: false }, borderWidth: 2, borderColor: '#fff' },
      series: clickToFilter(onPick),
    },
    series: [{ name: 'Connections', colorByPoint: true, data }],
  }), [data, total, centreLabel, onPick]);
  return <Chart options={options} />;
}

export function ColumnChart({ data, onPick }) {
  const options = useMemo(() => ({
    chart: { type: 'column', height: 300 },
    xAxis: { type: 'category', labels: { style: { color: COLORS.text, fontSize: '12px' } } },
    yAxis: { min: 0, allowDecimals: false, gridLineDashStyle: 'Dash' },
    legend: { enabled: false },
    tooltip: { pointFormatter() { return `<b>${fmt(this.y)}</b> connections`; }, headerFormat: '<span style="opacity:.75">{point.key}</span><br/>' },
    plotOptions: {
      column: { borderRadius: 4, pointPadding: 0.1, groupPadding: 0.12, colorByPoint: true, colors: PALETTE, dataLabels: { enabled: true, formatter() { return fmt(this.y); }, style: { fontSize: '12px', fontWeight: '600', color: COLORS.text, textOutline: 'none' } } },
      series: clickToFilter(onPick),
    },
    series: [{ name: 'Connections', data }],
  }), [data, onPick]);
  return <Chart options={options} />;
}
