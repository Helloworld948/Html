import { fmt } from '../lib/theme';

export default function KpiCard({ label, value, rule, tone = 'neutral', reference, showReference }) {
  let badge = null;
  if (showReference && reference != null) {
    const diff = value - reference;
    badge = diff === 0
      ? <span className="badge ok" title="Matches Summary 16-Sep-2026">✓ Matches summary</span>
      : <span className="badge warn" title={`Summary 16-Sep-2026 shows ${fmt(reference)}`}>Summary {fmt(reference)} ({diff > 0 ? '+' : ''}{fmt(diff)})</span>;
  }
  return (
    <article className={`kpi tone-${tone}`}>
      <h3>{label}</h3>
      <div className="kpi-value">{fmt(value)}</div>
      <p className="kpi-rule">{rule}</p>
      <div className="kpi-foot">{badge}</div>
    </article>
  );
}
