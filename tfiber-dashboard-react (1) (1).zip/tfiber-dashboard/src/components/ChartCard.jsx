export default function ChartCard({ title, subtitle, actions, className = '', children }) {
  return (
    <section className={`card ${className}`}>
      <header className="card-head">
        <div>
          <h2>{title}</h2>
          {subtitle && <p>{subtitle}</p>}
        </div>
        {actions}
      </header>
      <div className="card-body">{children}</div>
    </section>
  );
}
