# T-FIBER end-user connectivity dashboard

Static React + Highcharts dashboard. No Node.js, no build step, no database.
All libraries are in `vendor/`, so it also works without internet.

## Run
Browsers block `fetch()` from `file://`, so serve the folder over HTTP:

    python -m http.server 8080        # then open http://localhost:8080

Any static host works (IIS, Nginx, Apache, S3).

## Folder
    index.html                 page shell, loads scripts in order
    css/styles.css
    js/config.js               data paths, SAC "received" statuses, Top-N for operators
    js/mapper.js               original column names, text normalisation, alias tables
    js/calc.js                 filters, KPI rules, chart aggregation (pure functions)
    js/app.js                  React UI (htm templates) + Highcharts
    data/connections.json      SAMPLE: 1,502 records (replace with the full data later)
    data/summary_reference.json  figures from 'Summary 16-Sep-2026' (shown beside each KPI)
    vendor/                    react, react-dom, htm, highcharts
    tools/excel_to_json.py     optional: workbook -> connections.json

## Adding the full data
Replace `data/connections.json` with the full export; nothing else changes.
Two shapes are accepted:
- array of objects keyed by the workbook headers, or
- `{"columns":[...], "rows":[[...],...]}`, which is much smaller for very large files.

For hundreds of thousands of rows, use the columnar shape and serve the file gzip-compressed.
The columns used are listed in `tools/excel_to_json.py` and `js/mapper.js`.

## KPI rules (reproduce the 16-Sep-2026 summary on the full data)
- Total user connectivity: Household / Private Enterprise / GI-Enterprise with PO Status PO or POC
- PO / POC count: PO Status = PO / POC (the sheet has no "POS")
- Lit-Up: PO and Litup = Yes. Yet to Lit-Up: PO and Litup = No or blank
- Service Provisioned: PO, Lit-Up, Service Provisioned in (Yes, Disconnected)
- Service yet to be provisioned: Lit-Up minus Service Provisioned
- SAC received: PO Status PO with SAC Form Status in `sacReceived` (config.js). Yet to be received: Service Provisioned minus SAC received
- Disconnected: PO and Disconnection Status = Yes
- The switch above the charts changes the Lit-Up to Disconnected figures to PO + POC.

## Known differences from the workbook summary (full data)
- SAC received: 1,600 computed vs 1,606 in the summary (yet to be received 1,454 vs 1,448). The summary seems to include a manual adjustment; business team to confirm which statuses count as received.
- Warangal, Warangal Rural and Warangal Urban are kept as separate districts until the mapping is approved.
- Operator names are only trimmed; add approved spellings to `OPERATOR_ALIASES` in `js/mapper.js`.
