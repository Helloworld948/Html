/* Dashboard settings. Edit here - no build step needed. */
(function (g) {
  g.TF = g.TF || {};
  g.TF.config = {
    dataUrl: "data/connections.json",            // array of records, or {columns, rows}
    referenceUrl: "data/summary_reference.json", // figures from 'Summary 16-Sep-2026'
    asOfLabel: "16 Sep 2026",

    // Scope: only these records are used by the dashboard
    scopeCategories: ["Household", "Private Enterprise", "GI-Enterprise"],
    scopePoStatus: ["PO", "POC"],

    // SAC Form Status values that count as "received" (business team must confirm)
    sacReceived: ["Available", "Over E-mail", "Completed"],

    // Operator chart: show this many operators, group the rest as "Others"
    operatorTopN: 10
  };
})(typeof window !== "undefined" ? window : globalThis);
