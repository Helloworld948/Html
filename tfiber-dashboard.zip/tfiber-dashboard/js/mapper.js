/*
 * Source-data mapper.
 * The workbook's original column names live ONLY here (including the misspelt
 * "Connection Catogory"); everything else in the app uses the clean keys on the right.
 */
(function (g) {
  g.TF = g.TF || {};

  var SOURCE = {
    cat:      ["Connection Catogory", "Connection Category", "Connection Catogiry"],
    po:       ["PO Status"],
    lco:      ["LCO/MSI/TSP", "LCO/MSI"],
    lit:      ["Litup"],
    sp:       ["Service Provisioned (Yes/NO)"],
    sac:      ["SAC Form Status"],
    dis:      ["Disconnection Status"],
    dept:     ["Department"],
    sol:      ["Solution Type"],
    mode:     ["Delivery Mode (Switch/ Router/ ONT/Wireless)"],
    district: ["District"],
    pkg:      ["Package"],
    op:       ["LCO Operator Name"],
    gi:       ["GI Name"],
    mandal:   ["Mandal Name"]
  };

  // --- Approved alias tables: extend these as the business team confirms spellings ---
  var DISTRICT_ALIASES = {
    rangareddy: "Ranga Reddy",
    hanamkonda: "Hanumakonda", hanmakonda: "Hanumakonda", hanumakonda: "Hanumakonda",
    asifabad: "Kumuram Bheem Asifabad", kumurambheemasifabad: "Kumuram Bheem Asifabad",
    yadadribhongir: "Yadadri Bhuvanagiri", yadadribhuvanagiri: "Yadadri Bhuvanagiri",
    gadwal: "Jogulamba Gadwal", jogulambagadwal: "Jogulamba Gadwal",
    medchalmalkajgiri: "Medchal Malkajgiri", medchalmalkajigiri: "Medchal Malkajgiri",
    jayashankarbhupalapally: "Jayashankar Bhupalapally", jayashankarbhupalapalli: "Jayashankar Bhupalapally",
    rajannasircilla: "Rajanna Sircilla", rajannasiricilla: "Rajanna Sircilla",
    jangoan: "Jangaon", jangaon: "Jangaon"
    // Warangal / Warangal Rural / Warangal Urban are kept separate until the business confirms the mapping
  };
  var DEPARTMENT_ALIASES = {
    tribalwelfaredepartment: "Tribal Welfare",
    "transportroadsandbuildings": "Transport, Roads and Buildings",
    irrigationcad: "Irrigation & Command Area Development",
    "irrigationcommandareadevelopment": "Irrigation & Command Area Development",
    telanganafiredisasterresponseemergencyandcivildefence: "Telangana Fire Disaster Response Emergency and Civil Defence",
    telanganafiredisasterresponseemergencyandcivildefencedepartment: "Telangana Fire Disaster Response Emergency and Civil Defence",
    generaladministrationgad: "General Administration (GAD)",
    generaladministrationdepartmentgad: "General Administration (GAD)",
    revenuedepartment: "Revenue",
    minoritieswelfaredepartment: "Minorities Welfare",
    scheduledcastesdevelopmentdepartment: "Scheduled Castes Development",
    healthmedicalfamilywelfare: "Health, Medical & Family Welfare",
    healthmedicalandfamilywelfare: "Health, Medical & Family Welfare",
    environmentforestscienceandtechnology: "Environment, Forests, Science and Technology",
    environmentforestsscienceandtechnology: "Environment, Forests, Science and Technology",
    municipaladministrationandurbandevelopment: "Municipal Administration and Urban Development (MA&UD)",
    prrdpanchayatraj: "Panchayat Raj and Rural Development"
  };
  var OPERATOR_ALIASES = {
    // example: "pioneer e labs": "Pioneer"   (add once approved)
  };

  // --- text helpers ---
  function squash(v) { return String(v == null ? "" : v).trim().replace(/\s+/g, " "); }
  function lower(v) { return squash(v).toLowerCase(); }
  function compact(v) { return lower(v).replace(/[^a-z0-9]/g, ""); }
  function titleCase(s) {
    return s.toLowerCase().replace(/(^|[\s\-(])([a-z])/g, function (m, a, b) { return a + b.toUpperCase(); });
  }

  function yesNo(v) {
    var k = lower(v);
    if (!k) return "Blank";
    if (k === "yes") return "Yes";
    if (k === "no") return "No";
    if (k === "disconnected") return "Disconnected";
    return squash(v);
  }
  function category(v) {
    var k = lower(v).replace(/[\s_-]+/g, " ");
    if (k === "gi enterprise") return "GI-Enterprise";
    if (k === "household") return "Household";
    if (k === "private enterprise") return "Private Enterprise";
    return squash(v) || "Blank";
  }
  function poStatus(v) { var s = squash(v); return s ? (s.toUpperCase() === "PO" || s.toUpperCase() === "POC" ? s.toUpperCase() : s) : "Blank"; }
  function lcoType(v) { var s = squash(v); return !s ? "Blank" : (s.toLowerCase() === "lco" ? "LCO" : s); }
  function pkg(v) {
    var m = /^(?:package|pkg)[\s_-]*([a-z])$/i.exec(squash(v));
    return m ? "Package_" + m[1].toUpperCase() : (squash(v) || "Blank");
  }
  function solution(v) {
    var m = /^(?:solution[\s_-]*)?(\d)$/i.exec(squash(v));
    return m ? "Solution-" + m[1] : (squash(v) || "Blank");
  }
  function plain(v) { return squash(v) || "Blank"; }
  function sacStatus(v) {
    var k = lower(v);
    if (!k) return "Blank";
    if (k === "yet to connect") return "Yet to connect";
    if (k === "over e-mail" || k === "over email") return "Over E-mail";
    return titleCase(k).replace("E-Mail", "E-mail");
  }
  function district(v) {
    var s = squash(v); if (!s) return "Blank";
    return DISTRICT_ALIASES[compact(s)] || titleCase(s);
  }
  function department(v) {
    var s = squash(v); if (!s) return "Blank";
    return DEPARTMENT_ALIASES[compact(s)] || s;
  }

  // Operators: blank / Not Applicable / Not Available are separate classes (not merged, not charted)
  var UNASSIGNED = { "Blank": 1, "Not Applicable": 1, "Not Available": 1 };
  function operator(v) {
    var s = squash(v); if (!s) return "Blank";
    var k = s.toLowerCase();
    if (k === "not applicable") return "Not Applicable";
    if (k === "not available") return "Not Available";
    return OPERATOR_ALIASES[k] || s;
  }

  function findKeys(sampleRow) {
    var norm = {}; Object.keys(sampleRow).forEach(function (k) { norm[lower(k)] = k; });
    var out = {};
    Object.keys(SOURCE).forEach(function (key) {
      for (var i = 0; i < SOURCE[key].length; i++) {
        var hit = norm[lower(SOURCE[key][i])];
        if (hit) { out[key] = hit; return; }
      }
    });
    return out;
  }

  function normalizeRow(raw, keys) {
    var get = function (k) { return keys[k] ? raw[keys[k]] : null; };
    return {
      cat: category(get("cat")), po: poStatus(get("po")), lco: lcoType(get("lco")),
      lit: yesNo(get("lit")), sp: yesNo(get("sp")), sac: sacStatus(get("sac")), dis: yesNo(get("dis")),
      dept: department(get("dept")), sol: solution(get("sol")), mode: plain(get("mode")),
      district: district(get("district")), pkg: pkg(get("pkg")), op: operator(get("op")),
      gi: squash(get("gi")), mandal: squash(get("mandal"))
    };
  }

  /* Accepts [ {..}, ... ] or { columns:[..], rows:[[..], ..] } */
  function load(json, cfg) {
    var list;
    if (Array.isArray(json)) list = json;
    else if (json && json.columns && json.rows) {
      var cols = json.columns;
      list = json.rows.map(function (r) { var o = {}; for (var i = 0; i < cols.length; i++) o[cols[i]] = r[i]; return o; });
    } else throw new Error("Unsupported JSON shape: expected an array of records or {columns, rows}.");

    var keys = list.length ? findKeys(list[0]) : {};
    var scopeCat = {}, scopePo = {};
    cfg.scopeCategories.forEach(function (c) { scopeCat[c] = 1; });
    cfg.scopePoStatus.forEach(function (c) { scopePo[c] = 1; });

    var rows = [], excluded = { count: 0, reasons: {} };
    for (var i = 0; i < list.length; i++) {
      var r = normalizeRow(list[i], keys);
      var why = !scopeCat[r.cat] ? "Connection Category = " + r.cat : (!scopePo[r.po] ? "PO Status = " + r.po : null);
      if (why) { excluded.count++; excluded.reasons[why] = (excluded.reasons[why] || 0) + 1; continue; }
      rows.push(r);
    }
    return { rows: rows, excluded: excluded, totalSource: list.length, missingColumns: Object.keys(SOURCE).filter(function (k) { return !keys[k]; }) };
  }

  g.TF.mapper = { load: load, isUnassignedOperator: function (n) { return !!UNASSIGNED[n]; }, SOURCE: SOURCE };
})(typeof window !== "undefined" ? window : globalThis);
