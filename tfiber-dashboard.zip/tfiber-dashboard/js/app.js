/* T-FIBER dashboard UI: React (UMD) + htm templates + Highcharts. No build step. */
(function () {
  var useState = React.useState, useMemo = React.useMemo, useEffect = React.useEffect,
      useRef = React.useRef, useCallback = React.useCallback;
  var html = htm.bind(React.createElement);
  var T = window.TF, CFG = T.config, CALC = T.calc;

  var COLOR = { fiber: "#0e7c66", blue: "#2f5d9e", amber: "#c97d12", slate: "#9aa7b2", red: "#b8372e", ink: "#16222e", grid: "#e6ebef" };
  var CAT_COLOR = { "GI-Enterprise": COLOR.blue, "Household": COLOR.fiber, "Private Enterprise": COLOR.amber };
  var PKG_COLOR = { "Package_A": COLOR.blue, "Package_B": COLOR.fiber, "Package_C": COLOR.amber };

  var nf = function (n) { return Number(n || 0).toLocaleString("en-IN"); };
  var pct = function (a, b) { return b ? Math.round(a / b * 1000) / 10 : 0; };

  /* ---------- Multi-select filter ---------- */
  function MultiSelect(p) {
    var st = useState(false), open = st[0], setOpen = st[1];
    var qs = useState(""), q = qs[0], setQ = qs[1];
    var box = useRef(null);
    useEffect(function () {
      if (!open) return;
      var close = function (e) { if (box.current && !box.current.contains(e.target)) setOpen(false); };
      var esc = function (e) { if (e.key === "Escape") setOpen(false); };
      document.addEventListener("mousedown", close); document.addEventListener("keydown", esc);
      return function () { document.removeEventListener("mousedown", close); document.removeEventListener("keydown", esc); };
    }, [open]);

    var selected = p.selected || [];
    var shown = p.options.filter(function (o) { return !q || o.value.toLowerCase().indexOf(q.toLowerCase()) >= 0; });
    var label = !selected.length ? "All" : selected.length === 1 ? selected[0]
      : selected.length === p.options.length ? "All (" + selected.length + ")" : selected.length + " selected";
    var toggle = function (v) {
      p.onChange(selected.indexOf(v) >= 0 ? selected.filter(function (x) { return x !== v; }) : selected.concat(v));
    };
    return html`
      <div className="ms" ref=${box}>
        <button type="button" className=${selected.length ? "on" : ""} aria-expanded=${open} onClick=${function () { setOpen(!open); }}>
          <span><span className="lab">${p.label}</span><span className="val">${label}</span></span>
          <span className="caret">▾</span>
        </button>
        ${open && html`
          <div className="ms-panel">
            <input type="search" placeholder=${"Search " + p.label.toLowerCase()} value=${q} onChange=${function (e) { setQ(e.target.value); }} autoFocus />
            <div className="ms-actions">
              <button type="button" className="linkbtn" onClick=${function () { p.onChange(p.options.map(function (o) { return o.value; })); }}>Select all</button>
              <button type="button" className="linkbtn" onClick=${function () { p.onChange([]); }}>Clear all</button>
            </div>
            <div className="ms-list">
              ${shown.length ? shown.map(function (o) { return html`
                <label key=${o.value}>
                  <input type="checkbox" checked=${selected.indexOf(o.value) >= 0} onChange=${function () { toggle(o.value); }} />
                  <span>${o.value}</span><span className="n">${nf(o.count)}</span>
                </label>`; }) : html`<div className="ms-empty">No matching values</div>`}
            </div>
          </div>`}
      </div>`;
  }

  /* ---------- Highcharts wrapper ---------- */
  function Chart(p) {
    var ref = useRef(null);
    useEffect(function () {
      if (p.empty || !ref.current) return;
      var chart = Highcharts.chart(ref.current, p.options);
      return function () { chart.destroy(); };
    }, [p.options, p.empty]);
    if (p.empty) return html`<div className="empty" style=${{ minHeight: p.height }}>No Data Available</div>`;
    return html`<div ref=${ref} style=${{ height: p.height }}></div>`;
  }

  var baseOpts = {
    chart: { backgroundColor: "transparent", style: { fontFamily: "inherit" }, spacing: [6, 6, 6, 6], animation: { duration: 250 } },
    title: { text: null }, credits: { enabled: false }, legend: { enabled: false },
    accessibility: { enabled: false }
  };
  function merge(a, b) { return Highcharts.merge(a, b); }

  function barOptions(data, o) {
    return merge(baseOpts, {
      chart: { type: o.horizontal ? "bar" : "column" },
      xAxis: { type: "category", labels: { style: { color: COLOR.ink, fontSize: "12px" } }, lineColor: COLOR.grid, tickLength: 0 },
      yAxis: { title: { text: null }, gridLineColor: COLOR.grid, labels: { style: { color: "#5b6a77" }, formatter: function () { return nf(this.value); } } },
      tooltip: { pointFormatter: function () { return "<b>" + nf(this.y) + "</b> connections"; } },
      plotOptions: {
        series: {
          borderRadius: 2, pointPadding: 0.08, groupPadding: 0.06, cursor: o.onPick ? "pointer" : "default",
          dataLabels: { enabled: true, crop: false, overflow: "allow", style: { fontWeight: "500", textOutline: "none", color: COLOR.ink }, formatter: function () { return nf(this.y); } },
          point: { events: { click: function () { if (o.onPick && !this.options.noPick) o.onPick(this.name); } } }
        }
      },
      series: [{ name: "Connections", color: o.color || COLOR.blue, data: data }]
    });
  }
  function donutOptions(data, o) {
    return merge(baseOpts, {
      chart: { type: "pie" }, legend: { enabled: true, itemStyle: { fontWeight: "400", color: COLOR.ink } },
      tooltip: { pointFormatter: function () { return "<b>" + nf(this.y) + "</b> (" + Highcharts.numberFormat(this.percentage, 1) + "%)"; } },
      plotOptions: { pie: { innerSize: "58%", borderWidth: 2, cursor: o.onPick ? "pointer" : "default", showInLegend: true,
        dataLabels: { enabled: true, distance: 12, style: { fontWeight: "400", textOutline: "none", color: COLOR.ink },
          formatter: function () { return this.point.name + "<br/>" + nf(this.y) + " · " + Highcharts.numberFormat(this.percentage, 1) + "%"; } },
        point: { events: { click: function () { if (o.onPick) o.onPick(this.name); } } } } },
      series: [{ name: "Connections", data: data }]
    });
  }

  /* ---------- KPI blocks ---------- */
  function Stat(p) {
    var refEl = null;
    if (p.refVal != null) {
      var same = p.value === p.refVal;
      refEl = html`<span className=${"ref " + (!p.sample && same ? "ok" : !p.sample ? "warn" : "")}>
        ${"Workbook " + nf(p.refVal) + (!p.sample ? (same ? " · matches" : " · differs by " + nf(Math.abs(p.value - p.refVal))) : "")}</span>`;
    }
    return html`<div className=${"stat " + (p.tone || "")}>
      <span className="num">${nf(p.value)}</span><span className="lbl">${p.label}</span>${refEl}</div>`;
  }
  function Stage(p) {
    return html`<section className="stage"><h3>${p.title}</h3>${p.children}
      ${p.meter != null && html`<div><div className="meter" role="img" aria-label=${p.meterNote}><i style=${{ width: p.meter + "%" }}></i></div><span className="meter-note">${p.meterNote}</span></div>`}
    </section>`;
  }

  /* ---------- Operator table ---------- */
  function OperatorTable(p) {
    var qs = useState(""), q = qs[0], setQ = qs[1];
    var ss = useState({ key: "total", dir: -1 }), sort = ss[0], setSort = ss[1];
    var ps = useState(0), page = ps[0], setPage = ps[1];
    var size = 10;
    var rows = useMemo(function () {
      var r = p.rows.filter(function (o) { return !q || o.name.toLowerCase().indexOf(q.toLowerCase()) >= 0; });
      r = r.slice().sort(function (a, b) {
        var x = a[sort.key], y = b[sort.key];
        return (typeof x === "string" ? x.localeCompare(y) : x - y) * sort.dir;
      });
      return r;
    }, [p.rows, q, sort]);
    useEffect(function () { setPage(0); }, [q, p.rows]);
    var pages = Math.max(1, Math.ceil(rows.length / size));
    var cols = [["name", "Operator"], ["total", "Connections"], ["po", "PO"], ["poc", "POC"], ["lit", "Lit-Up"], ["sp", "Service provisioned"]];
    var head = function (c) { return html`<th key=${c[0]} aria-sort=${sort.key === c[0] ? (sort.dir > 0 ? "ascending" : "descending") : "none"}>
      <button type="button" onClick=${function () { setSort({ key: c[0], dir: sort.key === c[0] ? -sort.dir : (c[0] === "name" ? 1 : -1) }); }}>${c[1]}${sort.key === c[0] ? (sort.dir > 0 ? " ▲" : " ▼") : ""}</button></th>`; };
    return html`
      <div>
        <div className="tools"><input type="search" placeholder="Search operator name" value=${q} onChange=${function (e) { setQ(e.target.value); }} aria-label="Search operator name" />
          <span className="hint">${nf(rows.length)} of ${nf(p.rows.length)} operator values</span></div>
        <div className="tablewrap"><table>
          <thead><tr>${cols.map(head)}</tr></thead>
          <tbody>${rows.slice(page * size, page * size + size).map(function (o) {
            var un = T.mapper.isUnassignedOperator(o.name);
            return html`<tr key=${o.name}><td className=${un ? "tag" : ""}>${o.name}${un ? " (not an operator)" : ""}</td>
              <td>${nf(o.total)}</td><td>${nf(o.po)}</td><td>${nf(o.poc)}</td><td>${nf(o.lit)}</td><td>${nf(o.sp)}</td></tr>`; })}
          </tbody></table></div>
        <div className="pager"><span>Page ${page + 1} of ${pages}</span>
          <span><button type="button" disabled=${page === 0} onClick=${function () { setPage(page - 1); }}>Previous</button>
          ${" "}<button type="button" disabled=${page >= pages - 1} onClick=${function () { setPage(page + 1); }}>Next</button></span></div>
      </div>`;
  }

  /* ---------- Dashboard ---------- */
  function Dashboard(p) {
    var data = p.data, ref = p.reference;
    var fs = useState({}), filters = fs[0], setFilters = fs[1];
    var bs = useState("po"), basis = bs[0], setBasis = bs[1];
    var ds = useState(15), distN = ds[0], setDistN = ds[1];
    var ps = useState("column"), pkgType = ps[0], setPkgType = ps[1];
    var os = useState(CFG.operatorTopN), opN = os[0], setOpN = os[1];

    var facets = useMemo(function () { return CALC.facets(data.rows); }, [data]);
    var rows = useMemo(function () { return CALC.applyFilters(data.rows, filters); }, [data, filters]);
    var sacSet = useMemo(function () { var s = {}; CFG.sacReceived.forEach(function (x) { s[x] = 1; }); return s; }, []);
    var k = useMemo(function () { return CALC.kpis(rows, basis, sacSet); }, [rows, basis, sacSet]);
    var agg = useMemo(function () { return CALC.aggregate(rows); }, [rows]);

    var setField = useCallback(function (key, vals) { setFilters(function (f) { var n = Object.assign({}, f); n[key] = vals; return n; }); }, []);
    var pick = useCallback(function (key, val) {
      setFilters(function (f) {
        var cur = f[key] || [], n = Object.assign({}, f);
        n[key] = (cur.length === 1 && cur[0] === val) ? [] : [val];
        return n;
      });
    }, []);
    var activeCount = CALC.FILTERS.filter(function (f) { return (filters[f.key] || []).length; }).length;
    var noFilters = activeCount === 0;
    var sample = data.rows.length !== ref.total;
    var showRef = noFilters && ref;
    var basisRef = showRef && basis === "po";

    var chips = [];
    CALC.FILTERS.forEach(function (f) {
      var sel = filters[f.key] || [], total = facets[f.key].length;
      if (!sel.length) return;
      if (sel.length > 3) {
        chips.push(html`<span className="chip" key=${f.key}>${f.label}: ${sel.length === total ? "all " + total : sel.length + " selected"}
          <button type="button" aria-label=${"Remove " + f.label + " filter"} onClick=${function () { setField(f.key, []); }}>×</button></span>`);
      } else sel.forEach(function (v) {
        chips.push(html`<span className="chip" key=${f.key + v}>${f.label}: ${v}
          <button type="button" aria-label=${"Remove " + v} onClick=${function () { setField(f.key, sel.filter(function (x) { return x !== v; })); }}>×</button></span>`);
      });
    });

    /* chart options */
    var distData = useMemo(function () { return distN ? agg.district.slice(0, distN) : agg.district; }, [agg, distN]);
    var distOpts = useMemo(function () { return barOptions(distData, { horizontal: true, color: COLOR.blue, onPick: function (v) { pick("district", v); } }); }, [distData, pick]);
    var pkgOpts = useMemo(function () {
      var d = agg.pkg.map(function (x) { return { name: x.name, y: x.y, color: PKG_COLOR[x.name] || COLOR.slate }; });
      d.sort(function (a, b) { return a.name.localeCompare(b.name); });
      var onPick = function (v) { pick("pkg", v); };
      return pkgType === "donut" ? donutOptions(d, { onPick: onPick }) : barOptions(d, { onPick: onPick });
    }, [agg, pkgType, pick]);
    var opData = useMemo(function () {
      var top = agg.operators.slice(0, opN).map(function (o) { return { name: o.name, y: o.total }; });
      var rest = agg.operators.slice(opN).reduce(function (s, o) { return s + o.total; }, 0);
      if (rest) top.push({ name: "Others (" + (agg.operators.length - opN) + " operators)", y: rest, color: COLOR.slate, noPick: true });
      return top;
    }, [agg, opN]);
    var opOpts = useMemo(function () { return barOptions(opData, { horizontal: true, color: COLOR.fiber, onPick: function (v) { pick("op", v); } }); }, [opData, pick]);
    var catOpts = useMemo(function () {
      var d = agg.cat.map(function (x) { return { name: x.name, y: x.y, color: CAT_COLOR[x.name] || COLOR.slate }; });
      return barOptions(d, { onPick: function (v) { pick("cat", v); } });
    }, [agg, pick]);
    var poOpts = useMemo(function () {
      var d = agg.po.map(function (x) { return { name: x.name, y: x.y, color: x.name === "PO" ? "#35b79b" : "#e0a23a" }; });
      return donutOptions(d, { onPick: function (v) { pick("po", v); } });
    }, [agg, pick]);

    var empty = rows.length === 0;
    var base = k.base;
    var lcl = basis === "po" ? "PO " : "";
    var ex = data.excluded;
    var exText = ex.count ? " " + nf(ex.count) + " source record" + (ex.count > 1 ? "s" : "") + " excluded (" + Object.keys(ex.reasons).join(", ") + ")." : "";
    var opEx = agg.operatorExcluded;

    return html`
      <div>
        <header className="top">
          <div><h1>T-FIBER end-user connectivity</h1>
            <p>Telangana Fiber Grid Corporation · status as on ${CFG.asOfLabel}</p></div>
          <span className=${"badge " + (sample ? "sample" : "ok")}>
            ${sample ? "Sample data: " + nf(data.rows.length) + " of " + nf(ref.total) + " in-scope records" : "Full data: " + nf(data.rows.length) + " records match the workbook total"}</span>
        </header>

        <main className="wrap">
          <section className="filters" aria-label="Filters">
            <div className="filter-grid">
              ${CALC.FILTERS.map(function (f) { return html`<${MultiSelect} key=${f.key} label=${f.label} options=${facets[f.key]}
                selected=${filters[f.key]} onChange=${function (v) { setField(f.key, v); }} />`; })}
            </div>
            <div className="filter-foot">
              ${chips.length ? chips : html`<span className="hint">No filters applied. Charts also filter when you click a bar or slice.</span>`}
              <button type="button" className="reset" disabled=${noFilters} onClick=${function () { setFilters({}); }}>Reset filters</button>
            </div>
          </section>
          <p className="scope">Scope: Household, Private Enterprise and GI-Enterprise connections with PO Status PO or POC.${exText} Blank values are ignored in filter lists.</p>

          ${empty && html`<div className="nodata" role="status"><strong>No Data Available</strong>
            <span>No records match this filter combination.</span>
            <button type="button" className="reset" style=${{ marginLeft: 0 }} onClick=${function () { setFilters({}); }}>Reset filters</button></div>`}

          <section className="summary" aria-label="Key figures">
            <div className="hero">
              <h2>Total user connectivity</h2>
              <div className="big">${nf(k.total)}</div>
              <div className="split" role="img" aria-label=${"PO " + k.po + ", POC " + k.poc}>
                <i className="a" style=${{ width: pct(k.po, k.total) + "%" }}></i><i className="b" style=${{ width: pct(k.poc, k.total) + "%" }}></i></div>
              <div className="legend">
                <span><span className="dot" style=${{ background: "#35b79b" }}></span>PO <b>${nf(k.po)}</b></span>
                <span><span className="dot" style=${{ background: "#e0a23a" }}></span>POC <b>${nf(k.poc)}</b></span></div>
              <div className="formula">PO ${nf(k.po)} + POC ${nf(k.poc)} = ${nf(k.po + k.poc)}.
                ${ex.count ? " " + nf(ex.count) + " source record with PO Status “Network” is left out (workbook: " + nf(ref.mainSheetRecords) + " records, " + nf(ref.total) + " counted)." : ""}</div>
            </div>

            <div className="stages">
              <${Stage} title="Purchase orders">
                <${Stat} value=${k.po} label="PO count" refVal=${showRef ? ref.po : null} sample=${sample} />
                <${Stat} value=${k.poc} label="POC count" refVal=${showRef ? ref.poc : null} sample=${sample} />
              <//>
              <${Stage} title=${lcl + "Lit-up"} meter=${pct(k.lit, base)} meterNote=${pct(k.lit, base) + "% of " + lcl + "connections lit up"}>
                <${Stat} value=${k.lit} tone="good" label="Lit-Up count" refVal=${basisRef ? ref.litUp : null} sample=${sample} />
                <${Stat} value=${k.yet} tone="pend" label="Yet to Lit-Up count" refVal=${basisRef ? ref.yetToLitUp : null} sample=${sample} />
              <//>
              <${Stage} title=${lcl + "Service"} meter=${pct(k.sp, k.lit)} meterNote=${pct(k.sp, k.lit) + "% of lit-up provisioned"}>
                <${Stat} value=${k.sp} tone="good" label="Service provisioned" refVal=${basisRef ? ref.serviceProvisioned : null} sample=${sample} />
                <${Stat} value=${k.spYet} tone="pend" label="Service yet to be provisioned" refVal=${basisRef ? ref.serviceYetToProvision : null} sample=${sample} />
              <//>
              <${Stage} title=${lcl + "SAC form"} meter=${pct(k.sac, k.sp)} meterNote=${pct(k.sac, k.sp) + "% of provisioned have SAC form"}>
                <${Stat} value=${k.sac} tone="good" label="SAC form received" refVal=${basisRef ? ref.sacReceived : null} sample=${sample} />
                <${Stat} value=${k.sacYet} tone="pend" label="SAC form yet to be received" refVal=${basisRef ? ref.sacYetToReceive : null} sample=${sample} />
              <//>
              <${Stage} title=${lcl + "Disconnections"}>
                <${Stat} value=${k.dis} tone="bad" label="Disconnected" refVal=${basisRef ? ref.disconnected : null} sample=${sample} />
              <//>
            </div>
          </section>

          <div className="basis">
            <span>Lit-up, service, SAC and disconnection figures count:</span>
            <span className="seg" role="group" aria-label="KPI basis">
              <button type="button" aria-pressed=${basis === "po"} onClick=${function () { setBasis("po"); }}>PO only (matches workbook)</button>
              <button type="button" aria-pressed=${basis === "all"} onClick=${function () { setBasis("all"); }}>PO + POC</button></span>
          </div>

          <div className="grid">
            <section className="card span-7">
              <header><div><h3>District-wise connections</h3><p className="hint">Highest to lowest · click a bar to filter</p></div>
                <select value=${distN} onChange=${function (e) { setDistN(Number(e.target.value)); }} aria-label="Districts shown">
                  <option value="10">Top 10</option><option value="15">Top 15</option><option value="0">All districts</option></select></header>
              <${Chart} options=${distOpts} empty=${empty || !distData.length} height=${Math.max(300, distData.length * 26 + 40)} />
            </section>

            <section className="card span-5">
              <header><div><h3>Package-wise connections</h3><p className="hint">Click to filter</p></div>
                <span className="seg"><button type="button" aria-pressed=${pkgType === "column"} onClick=${function () { setPkgType("column"); }}>Columns</button>
                  <button type="button" aria-pressed=${pkgType === "donut"} onClick=${function () { setPkgType("donut"); }}>Donut</button></span></header>
              <${Chart} options=${pkgOpts} empty=${empty || !agg.pkg.length} height=${320} />
            </section>

            <section className="card span-7">
              <header><div><h3>LCO operator-wise connections</h3><p className="hint">Remaining operators grouped as Others</p></div>
                <select value=${opN} onChange=${function (e) { setOpN(Number(e.target.value)); }} aria-label="Operators shown">
                  <option value="10">Top 10</option><option value="15">Top 15</option></select></header>
              <${Chart} options=${opOpts} empty=${empty || !opData.length} height=${Math.max(300, opData.length * 28 + 40)} />
              <p className="note">Not charted: ${nf(opEx["Not Applicable"])} Not Applicable · ${nf(opEx["Not Available"])} Not Available · ${nf(opEx["Blank"])} Blank. Full list in the table below.</p>
            </section>

            <div className="span-5" style=${{ display: "grid", gap: "12px", alignContent: "start" }}>
              <section className="card">
                <header><div><h3>Connection category</h3><p className="hint">Click to filter</p></div></header>
                <${Chart} options=${catOpts} empty=${empty} height=${230} />
              </section>
              <section className="card">
                <header><div><h3>PO versus POC</h3><p className="hint">Explains the total user connectivity</p></div></header>
                <${Chart} options=${poOpts} empty=${empty} height=${250} />
              </section>
            </div>

            <section className="card span-12">
              <header><div><h3>Operator details</h3><p className="hint">All operator values for the current filters; sort by clicking a heading</p></div></header>
              ${empty ? html`<div className="empty">No Data Available</div>` : html`<${OperatorTable} rows=${agg.operatorTable} />`}
            </section>
          </div>
        </main>
      </div>`;
  }

  /* ---------- App: fetch static JSON, then render ---------- */
  function App() {
    var s = useState({ status: "loading" }), state = s[0], setState = s[1];
    useEffect(function () {
      var get = function (u) { return fetch(u).then(function (r) { if (!r.ok) throw new Error(u + " returned HTTP " + r.status); return r.json(); }); };
      Promise.all([get(CFG.dataUrl), get(CFG.referenceUrl)]).then(function (res) {
        var data = T.mapper.load(res[0], CFG);
        setState({ status: "ready", data: data, ref: res[1] });
      }).catch(function (e) { setState({ status: "error", message: String(e.message || e) }); });
    }, []);
    if (state.status === "loading") return html`<p className="boot">Loading dashboard…</p>`;
    if (state.status === "error") return html`<div className="fatal"><h2>The data could not be loaded</h2>
      <p>${state.message}</p>
      <p>Browsers block <code>fetch()</code> on <code>file://</code> pages. Serve this folder over HTTP, for example
      <code>python -m http.server 8080</code> in this folder, then open <code>http://localhost:8080</code>. Any static web server (IIS, Nginx, Apache) also works.</p></div>`;
    if (state.data.missingColumns.length) console.warn("Columns not found in JSON:", state.data.missingColumns);
    return html`<${Dashboard} data=${state.data} reference=${state.ref} />`;
  }

  ReactDOM.createRoot(document.getElementById("root")).render(React.createElement(App));
})();
