/* Filtering, KPI rules and chart aggregation. Pure functions - no DOM. */
(function (g) {
  g.TF = g.TF || {};
  var M = function () { return g.TF.mapper; };

  var FILTERS = [
    { key: "cat",      label: "Connection category" },
    { key: "dept",     label: "Department" },
    { key: "po",       label: "PO status" },
    { key: "lco",      label: "LCO / MSI / TSP" },
    { key: "sol",      label: "Solution type" },
    { key: "mode",     label: "Delivery mode" },
    { key: "district", label: "District" },
    { key: "pkg",      label: "Package" },
    { key: "op",       label: "LCO operator" }
  ];

  function facets(rows) {
    var out = {};
    FILTERS.forEach(function (f) {
      var m = {};
      for (var i = 0; i < rows.length; i++) {
        var v = rows[i][f.key];
        if (v === "Blank") continue;                                   // ignore blanks by default
        if (f.key === "op" && M().isUnassignedOperator(v)) continue;   // NA / Not Available are not operators
        m[v] = (m[v] || 0) + 1;
      }
      out[f.key] = Object.keys(m).map(function (k) { return { value: k, count: m[k] }; })
        .sort(function (a, b) { return b.count - a.count || a.value.localeCompare(b.value); });
    });
    return out;
  }

  function applyFilters(rows, filters) {
    var active = [];
    FILTERS.forEach(function (f) {
      var sel = filters[f.key];
      if (sel && sel.length) { var set = {}; sel.forEach(function (v) { set[v] = 1; }); active.push([f.key, set]); }
    });
    if (!active.length) return rows;
    var out = [];
    for (var i = 0; i < rows.length; i++) {
      var r = rows[i], ok = true;
      for (var j = 0; j < active.length; j++) { if (!active[j][1][r[active[j][0]]]) { ok = false; break; } }
      if (ok) out.push(r);
    }
    return out;
  }

  /*
   * KPI rules (reproduce 'Summary 16-Sep-2026'):
   *   basis "po"  : Lit-up..Disconnected use PO records only (matches the workbook summary)
   *   basis "all" : same rules over PO + POC
   */
  function kpis(rows, basis, sacSet) {
    var k = { total: rows.length, po: 0, poc: 0, lit: 0, yet: 0, sp: 0, sac: 0, dis: 0, base: 0 };
    for (var i = 0; i < rows.length; i++) {
      var r = rows[i];
      if (r.po === "PO") k.po++; else if (r.po === "POC") k.poc++;
      if (basis === "po" && r.po !== "PO") continue;
      k.base++;
      if (r.lit === "Yes") { k.lit++; if (r.sp === "Yes" || r.sp === "Disconnected") k.sp++; }
      else if (r.lit === "No" || r.lit === "Blank") k.yet++;
      if (sacSet[r.sac]) k.sac++;
      if (r.dis === "Yes") k.dis++;
    }
    k.spYet = Math.max(0, k.lit - k.sp);     // PO Lit-Up - Service Provisioned
    k.sacYet = Math.max(0, k.sp - k.sac);    // Service Provisioned - SAC Received
    return k;
  }

  function sortedCounts(map) {
    return Object.keys(map).map(function (k) { return { name: k, y: map[k] }; })
      .sort(function (a, b) { return b.y - a.y || a.name.localeCompare(b.name); });
  }

  function aggregate(rows) {
    var d = {}, p = {}, c = {}, s = {}, ops = {}, excl = { "Blank": 0, "Not Applicable": 0, "Not Available": 0 };
    for (var i = 0; i < rows.length; i++) {
      var r = rows[i];
      if (r.district !== "Blank") d[r.district] = (d[r.district] || 0) + 1;
      if (r.pkg !== "Blank") p[r.pkg] = (p[r.pkg] || 0) + 1;
      c[r.cat] = (c[r.cat] || 0) + 1;
      s[r.po] = (s[r.po] || 0) + 1;
      var o = ops[r.op] || (ops[r.op] = { name: r.op, total: 0, po: 0, poc: 0, lit: 0, sp: 0 });
      o.total++; if (r.po === "PO") o.po++; else if (r.po === "POC") o.poc++;
      if (r.lit === "Yes") { o.lit++; if (r.sp === "Yes" || r.sp === "Disconnected") o.sp++; }
    }
    var table = Object.keys(ops).map(function (k) { return ops[k]; });
    var named = table.filter(function (o) { return !M().isUnassignedOperator(o.name); })
      .sort(function (a, b) { return b.total - a.total || a.name.localeCompare(b.name); });
    Object.keys(excl).forEach(function (k) { excl[k] = ops[k] ? ops[k].total : 0; });
    return {
      district: sortedCounts(d), pkg: sortedCounts(p), cat: sortedCounts(c), po: sortedCounts(s),
      operators: named, operatorTable: table, operatorExcluded: excl
    };
  }

  g.TF.calc = { FILTERS: FILTERS, facets: facets, applyFilters: applyFilters, kpis: kpis, aggregate: aggregate };
})(typeof window !== "undefined" ? window : globalThis);
